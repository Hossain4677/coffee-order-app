let orders = [];
let cart = [];
let currentUser = "";

function showForm(type) {
  document.getElementById("mainPage").classList.add("hidden");
  document.getElementById("userLogin").classList.add("hidden");
  document.getElementById("adminLogin").classList.add("hidden");
  if (type === "user") document.getElementById("userLogin").classList.remove("hidden");
  else document.getElementById("adminLogin").classList.remove("hidden");
}

function goBack() {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  document.getElementById("mainPage").classList.remove("hidden");
}

function userLogin() {
  const name = document.getElementById("userName").value;
  const pass = document.getElementById("userPass").value;
  if (name && pass) {
    currentUser = name;
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    document.getElementById("userSection").classList.remove("hidden");
    renderMenuItems();
    renderUserCart();
    renderUserOrders();
  }
}

function adminLogin() {
  const name = document.getElementById("adminName").value;
  const pin = document.getElementById("adminPin").value;
  if (pin === "4677") {
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    document.getElementById("adminSection").classList.remove("hidden");
    renderAdminOrders();
  }
}

function renderMenuItems() {
  const menu = document.getElementById("menuList");
  const drinks = [
    "Nescafe with milk",
    "Nescafe Black",
    "Turkish Coffee",
    "Black Coffee",
    "Black Tea",
    "Green Tea",
    "Arabic Tea",
    "Water",
    "Arabic Coffee",
    "Frach Coffee",
    "Milk Tea"
  ];
  menu.innerHTML = "";
  drinks.forEach(drink => {
    const box = document.createElement("div");
    box.className = "order-box";
    box.innerHTML = `
      ${drink}<br/>
      <button onclick="addToCart('${drink}')">Add to Cart</button>
    `;
    menu.appendChild(box);
  });
}

function addToCart(drink) {
  cart.push(drink);
  renderUserCart();
}

function renderUserCart() {
  const cartList = document.getElementById("cartItems");
  cartList.innerHTML = "";
  cart.forEach((item, index) => {
    const box = document.createElement("div");
    box.className = "order-box";
    box.innerHTML = `${item} <button onclick="removeFromCart(${index})">Remove</button>`;
    cartList.appendChild(box);
  });
}

function removeFromCart(index) {
  cart.splice(index, 1);
  renderUserCart();
}

function placeOrder() {
  cart.forEach(drink => {
    orders.push({ id: Date.now() + Math.random(), user: currentUser, drink, status: "Received" });
  });
  cart = [];
  renderUserCart();
  renderUserOrders();
  renderAdminOrders();
}

function renderUserOrders() {
  const list = document.getElementById("userOrders");
  list.innerHTML = "";
  orders.filter(o => o.user === currentUser).forEach(order => {
    const box = document.createElement("div");
    box.className = "order-box";
    box.innerHTML = `${order.drink} - <strong>${order.status}</strong>`;
    list.appendChild(box);
  });
}

function renderAdminOrders() {
  const list = document.getElementById("adminOrders");
  list.innerHTML = "";
  orders.forEach(order => {
    const box = document.createElement("div");
    box.className = "order-box";
    box.innerHTML = `
      <strong>${order.user}</strong> ordered <em>${order.drink}</em><br/>
      <select onchange="updateStatus(${order.id}, this.value)">
        <option ${order.status === "Received" ? "selected" : ""}>Received</option>
        <option ${order.status === "Processing" ? "selected" : ""}>Processing</option>
        <option ${order.status === "Completed" ? "selected" : ""}>Completed</option>
      </select>
    `;
    list.appendChild(box);
  });
}

function updateStatus(id, status) {
  const order = orders.find(o => o.id === id);
  if (order) order.status = status;
  renderUserOrders();
  renderAdminOrders();
}
